alter table users ENGINE = InnoDB character set utf8;
alter table stages ENGINE = InnoDB character set utf8;
alter table roles ENGINE = InnoDB character set utf8;
alter table units ENGINE = InnoDB character set utf8;
