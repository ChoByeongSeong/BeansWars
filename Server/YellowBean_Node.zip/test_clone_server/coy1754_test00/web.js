console.log('Starting app.js');
const express = require('express');
const mysql = require('mysql');
const jwt = require('jsonwebtoken');
const _ = require('lodash');
const Enumerable = require('linq');
const bodyParser = require('body-parser');
const dbConf = require('./db_conf');
const app = express();
const router = require('./routers/routers');
const router_api = require('./routers/router_api');

app.use(bodyParser.json());
app.use(express.json());
app.use('/', router);
app.use('/api', router_api);

var eSortType = {
    None :-1,
    Favorite :0,
    Clear:1,
    ElapsedScore:2,
    CreateAt: 3
};

// const connectDB = (callback)=>{
//     var con = mysql.createConnection(debConf.cafe24);
//     con.connect((err)=>{
//         if(err){
//             console.log(err);
//             con.end();
//             throw err;
//         }else{
//             console.log('DB서버 접속성공!');
//             callback(con);
//         }
//     });
// };

// var debConf = {
//     local: {
//         host:dbConf.local.host,
//         user:dbConf.local.user,
//         password:dbConf.local.password,
//         database:dbConf.local.database,
//         multipleStatements: true
//     },
//     cafe24: {
//         host:dbConf.cafe24.host,
//         user:dbConf.cafe24.user,
//         password:dbConf.cafe24.password,
//         database:dbConf.cafe24.database,
//         multipleStatements: true
//     }
// };
 
// function groupBy(list, keyGetter) {
//     const map = new Map();
//     list.forEach((item) => {
//         const key = keyGetter(item);
//         const collection = map.get(key);
//         if (!collection) {
//             map.set(key, [item]);
//         } else {
//             collection.push(item);
//         }
//     });
//     return map;
// }

app.listen(8001, ()=>{
    console.log("서버가 시작 되었습니다. 포트:3000");
});
