const express = require('express');
const mysql = require('mysql');
const jwt = require('jsonwebtoken');
var router = express.Router();

var debConf={
    local:{
        host:'192.168.0.116',
        user:'root',
        password:'root',
        database:'test',
        multipleStatements: true
    },
    cafe24:{
        host:'10.0.0.1',
        user:'coy1754',
        password:'cZ4rxc4jLfTgYpV',
        database:'coy1754',
        multipleStatements: true
    }
}

var pool = mysql.createPool(debConf.cafe24);

router.delete('/stage/:user_id/stage_id',verifyToken,(req,res)=>{
    var userId = req.params.user_id;
    var stageId = parseInt(req.params.stage_id);
    jwt.verify(req.token,'apple',(err,authData)=>{
        if(err)
        {
            console.log(err);
            res.sendStatus(403);
        }else{
            var sql = `select *from roles where user_id='${userId}';`;
            pool.getConnection((err,con)=>{
                if(err) throw err;
                con.query(sql,(err,results,fields)=>{
                    if(err)
                    {
                        console.log(err);
                        res.json({
                            cmd:901,
                            err:err
                        });
                        con.release();
                        throw err;
                    }else if(!err&&!results==null)
                    {
                        sql = `delete from stages where stage_id=${stageId};`;
                        con.query(sql,(err,results,fields)=>{
                            if(err)
                            {
                                console.log(err);
                                res.json({
                                    cmd:901,
                                    err,err
                                });
                                con.release();
                                throw err;
                            }else{
                                console.log('스테이지 삭제 성공');
                                con.release();
                                res.json({
                                    cmd:900,
                                    status:200,
                                    message:'스테이지 삭제 성공'
                                });
                            }
                        });
                    }
                });
            });
        }
    });
});

//토큰이 있냐?
function verifyToken(req, res, next){
    
    const bearerHeader = req.headers['authorization'];
    console.log(typeof(bearerHeader));

    if( typeof(bearerHeader) !== 'undefined' ){     
        //헤더에 토큰 정보가 있어 
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        req.token = bearerToken;
        next();
    }else{
        //정보가 없어 
        console.log('토큰 없음');
        res.json({
            status: 403, 
            message: '토큰이 없습니다.'
        });
    }
}

module.exports = router;