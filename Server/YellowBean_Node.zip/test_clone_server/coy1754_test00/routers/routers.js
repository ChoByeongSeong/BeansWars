const express = require('express');
var router = express.Router();
const dateFormat = require('dateformat');

//미들웨어 
router.use('/', (req, res, next)=>{
    var now = new Date();
    req.requestTime = dateFormat(now, 'dddd, mmmm, dS, yyyy, h:MM:ss TT');
    next();
});

router.get('/', (req, res)=>{
    res.send(`<h1>${req.requestTime.toLocaleString()}</h1>`);
});

module.exports = router;