const express = require('express');
const mysql = require('mysql');
const jwt = require('jsonwebtoken');
const _ = require('lodash');
const bodyParser = require('body-parser');
var router = express.Router();

router.use(bodyParser.json());

var debConf={
    local:{
        host:'192.168.0.116',
        user:'root',
        password:'root',
        database:'test',
        multipleStatements: true
    },
    cafe24:{
        host:'10.0.0.1',
        user:'coy1754',
        password:'cZ4rxc4jLfTgYpV',
        database:'coy1754',
        multipleStatements: true,
        connectionLimit:5000
    }
}

var pool = mysql.createPool(debConf.cafe24);

router.post('/doLogin', (req, res) => {

    pool.getConnection((err, con) => 
    {
        /**
         * 로그인 시도가 들어왔다.
         * 아이디가 디비에 있는지 확인한다.
         * 없으면 추가한다.
         * 토큰을 보내준다.
         */

         if(err)
         {
             throw err;
         }
        
        // 받아온 유저 정보
        var user = req.body;
        var sucessed = true;

        // 받아온 유저 id가 있는지 확인한다.
        var sql = `select *from users where user_id = '${user.id}';`
        con.query(sql, (err, results, fields) => 
        {
            if(err)
            {
                sucessed = false;

                console.log(err);
                res.json({
                    cmd: 301,
                    err: err
                });
                con.release();
            }

            else
            {
                // 있는지 없는지 확인한다.
                // 아이디가 없다면. 추가한다.
                if(results[0] == null)
                {
                    sql = `insert into users(user_id,user_name,country,device_id) values('${req.body.id}','${req.body.userName}','${req.body.country}','${req.body.deviceId}');`;
                    con.query(sql, (err, results, fields) => 
                    {
                        if(err)
                        {
                            sucessed = false;

                            console.log(err);
                            res.json({
                                cmd: 302,
                                err: err
                            });
                            con.release();
                        }
                    });
                }else if(results[0]!=null)
                {
                    sql = `update users set country = '${req.body.country}',user_name = '${req.body.userName}',device_id='${req.body.deviceId}' where user_id='${req.body.id}';`;
                    con.query(sql,(err,results,fields)=>
                    {
                        if(err)
                        {
                            sucessed = false;
                            console.log(err);
                            res.json({
                                cmd:302,
                                err:err
                            });
                            con.release();
                        }
                    });               
                }
            }
        });

        if(sucessed)
        {
            jwt.sign({ user }, 'apple', { expiresIn: '2d' }, (err, token) => {
                res.json({
                    cmd: 300,
                    message: '토큰발급 성공',
                    status: 200,
                    token: token
                });
            });
        }
    });
});

router.get('/stages/:sort_type',verifyToken,(req,res)=>{
    var sort_type = parseInt(req.params.sort_type);

    jwt.verify(req.token,'apple',(err,authData)=>{
        if(err)
        {
            console.log(err);
            res.sendStatus(403);
        }else
        {
            var sql;

            switch(sort_type)
            {
                case -1:
                {
                    sql =`select stages.*, users.user_name from stages
                    inner join users on users.user_id = stages.user_id order by rand() limit 10;`;
                }
                break;
                case 0:
                {
                    sql = `select stages.*, users.user_name from stages
                    inner join users on users.user_id = stages.user_id order by favorite_count DESC limit 10;`;

                }
                break;
                case 1:
                {
                    sql=`select stages.*, users.user_name from stages
                    inner join users on users.user_id = stages.user_id order by clear_count desc limit 10;`
                }
                break;
                case 2:
                {
                    sql =`select stages.*, users.user_name from stages
                    inner join users on users.user_id = stages.user_id order by elapsed_score desc limit 10;`
                }
                break;
                case 3:
                {
                    sql=`select stages.*, users.user_name from stages
                    inner join users on users.user_id = stages.user_id order by created_at desc limit 10;`
                }
                break;
            }
            console.log(sql);

            pool.getConnection((err,con)=>{
                if(err) throw err;
                con.query(sql,(err,results,fields)=>{
                 
                    var result;
                    if(err)
                    {
                        result ={
                            cmd: 401,
                            err:err
                        };
                        con.release();
                    }
                    else
                    {
                        result = {
                            cmd:400,
                            message:'성공',
                            status:200,
                            arrStageInfo:results
                        };
                        con.release();                                             
                    }
                    res.json(result);
                });
            });
        }
    });
});

router.post('/failedStage',verifyToken,(req,res)=>{
    jwt.verify(req.token,'apple',(err,authData)=>{
        if(err)
        {
            console.log(err);
            res.sendStatus(403);
        }else{
            sql = `update stages set elapsed_score = elapsed_score+10 where stage_id=${req.body.stage_id};`;
            pool.getConnection((err,con)=>{
                if(err) throw err;
                con.query(sql,(err,results,fields)=>{
                    
                    if(err)
                    {
                        console.log(err);
                        res.json({
                            cmd:431,
                            err:err
                        });
                        con.release();
                    }else{
                        res.json({
                            cmd:430,
                            message:'스테이지 누적점수 증가',
                            status:200
                        });
                        con.release();
                    }
                });
            });
        }
    });
});

router.post('/doFavoriteStage',verifyToken,(req,res)=>{
    jwt.verify(req.token,'apple',(err,authData)=>{
        if(err)
        {
            console.log(err);
            res.sendStatus(403);
        }else{
            sql = `update stages set favorite_count = favorite_count+1 where stage_id=${req.body.stage_id};`;
            pool.getConnection((err,con)=>{
                if(err) throw err;
                con.query(sql,(err,results,fields)=>{
                    
                    if(err)
                    {
                        res.json({
                            cmd:441,
                            err:err
                        });
                        con.release();
                    }else{
                        res.json({
                            cmd:440,
                            message:'좋아요 카운트 증가',
                            status:200
                        });
                        con.release();
                    }
                });
            });
        }
    });
});

router.post('/clearStage',verifyToken,(req,res)=>{
    jwt.verify(req.token,'apple',(err,authData)=>{
        if(err)
        {
            console.log(err);
            res.sendStatus(403);
        }else{
            sql =  `select elapsed_score from stages where stage_id=${req.body.stage_id};`+
                   `update stages set clear_count= clear_count+1 where stage_id=${req.body.stage_id};`+
                   `update users,stages set users.score= (users.score+${req.body.stage_elapsed_score}) where ((users.user_id = '${req.body.user_id}')AND(stages.stage_id=${req.body.stage_id}));`+
                   `update stages set elapsed_score = default where stage_id = ${req.body.stage_id};`;
            pool.getConnection((err,con)=>{
                if(err) throw err;
                con.query(sql,(err,results,fields)=>{
                   
                    var result;
                    if(err)
                    {
                        result ={
                            cmd:421,
                            err:err
                        };
                        con.release();
                    }else{
                        result={
                            cmd:420,
                            message:'스테이지클리어',
                            status:200
                        }
                        con.release();
                    }
                    res.json(result);
                });
            });
        }
    });
});

router.post('/doSaveStage',verifyToken,(req,res)=>{
    var stageInfo = req.body.stageInfo;
    var arrUnitInfo = req.body.arrUnitInfo;

    jwt.verify(req.token,'apple',(err,authData)=>{
        if(err)
        {
            console.log(err);
            res.sendStatus(403);
        }else{
            pool.getConnection((err,con)=>{
                if(err) throw err;
                var title = stageInfo.title;
                var userId = stageInfo.user_id;
                var mapId = stageInfo.map_id;

                var sql = `insert into stages(title,user_id,map_id) values('${title}','${userId}',${mapId});`;

                con.query(sql,(err,results,fields)=>{
                    if(err)
                    {
                        res.json({
                            cmd:501,
                            err:err
                        });
                        con.release();
                        throw err;
                    }else{
                        sql = 'select last_insert_id();';

                        con.query(sql,(err,results,fields)=>{
                            if(err)
                            {
                                console.log(err);
                                res.json({
                                    cmd:501,
                                    err:err
                                });
                                con.release();
                                throw err;
                            }else{
                                var r = JSON.stringify(results);
                                 r = r.substring(21,r.length-2);
                                 r = Number(r);
                                 console.log(r);
                                 sql = 'insert into units(unit_name,x,y,z,color,stage_id) values';

                                 arrUnitInfo.forEach(e => {
                                     sql += `('${e.unit_name}',${e.x},${e.y},${e.z},${e.color},${r}),`
                                 });
                                 sql = sql.substring(0,sql.length - 1) +';';                               
                                 con.query(sql,(err,results,fields)=>{
                                     if(err)
                                     {
                                        sql=`delete from units where stage_id${r};`
                                        con.query(sql,(err,results,fields)=>{
                                            if(err)
                                            {
                                                console.log(err);
                                                res.json({
                                                    cmd:501,
                                                    err:err
                                                });
                                                con.release();
                                                throw err;
                                            }else{
                                                console.log('스테이지정보 삭제 완료');
                                            }
                                        });
                                        console.log(err);
                                        res.json({
                                            cmd:501,
                                            err:err
                                        });
                                        con.release();
                                        throw err;
                                     }else{
                                         console.log('성공');
                                         res.json({
                                             cmd:500,
                                             status:200,
                                             message:'저장 성공'
                                         });                                                           
                                         con.release();    
                                     }
                                 });
                            }
                        }); //inner con.query end
                    }
                }); //con.query end
            });  //pool.getConnection end
        }
    }); //jwt.verify end
});

router.get('/getRank/:user_id',verifyToken,(req,res)=>{
    console.log('getRank params : ',req.params.user_id);
    jwt.verify(req.token,'apple',(err,authData)=>{
        if(err)
        {
            console.log(err);
            res.sendStatus(403);
        }else{
            sql = `select user_id, score,rank,user_name,country from(select user_id,
                score,
                user_name,
                country,
                @vRank:=@vRank+1 as rank
                from users as p,(select @vRank:=0)as r order by score desc limit 50)as cnt;
                `;
            pool.getConnection((err,con)=>{
                if(err) throw err;
                con.query(sql,(err,results,fields)=>{
                    
                    var result;
                    if(err)
                    {
                        result ={
                            cmd:701,
                            err:err
                        };
                        con.release();
                    }else{
                        result ={
                            cmd:700,
                            message:'상위 랭킹조회 성공',
                            status:200,
                            arrUserInfo:results
                        };
                        con.release();
                    }
                    console.log(result);
                    res.send(result);
                });
            });
        }
    });
});

router.get('/getMyRank/:user_id',verifyToken,(req,res)=>{
    console.log('getMyRank params : ',req.params.user_id);
    jwt.verify(req.token,'apple',(err,authData)=>{
        if(err)
        {
            console.log(err);
            res.sendStatus(403);
        }else{
            sql = `select user_id, score,rank,user_name,country from(select user_id,
                score,
                user_name,
                country,
                @vRank:=@vRank+1 as rank
                from users as p,(select @vRank:=0)as r order by score desc )as cnt where user_id='${req.params.user_id}';`;
            pool.getConnection((err,con)=>{
                if(err) throw err;
                con.query(sql,(err,results,fields)=>{
                    
                    var result;
                    if(err)
                    {
                        result ={
                            cmd:801,
                            err:err
                        };
                        con.release();
                    }else{
                        result={
                            cmd:800,
                            message:'나의 랭킹조회 성공',
                            status:200,
                            userInfo:results
                        };
                        con.release();
                    }
                    console.log(result);
                    res.send(result);
                });
            });
        }
    });
});

router.post('/doPlay',verifyToken,(req,res)=>{
    jwt.verify(req.token,'apple',(err,authData)=>{
        if(err)
        {
            console.log(err);
            res.sendStatus(403);
        }else{
            pool.getConnection((err,con)=>{
                if(err) throw err;
                var snum = req.body.stage_id;
                var sql = `select *from units where stage_id = ${snum};`;
                con.query(sql,(err,results,fields)=>{
                    if(err)
                    {
                        console.log(err);
                        res.json({
                            cmd:601,
                            err:err
                        });
                        con.release();
                        throw err;
                    }else{
                        var result ={
                            cmd:600,
                            status:200,
                            arrUnitInfo:results,
                            message:'목록 불러오기 성공'
                        };
                        con.release();
                        console.log(result);
                        res.send(result);
                    }
                });
            });
        }
    });
});

//토큰이 있냐?
function verifyToken(req, res, next){
    
    const bearerHeader = req.headers['authorization'];
    console.log(typeof(bearerHeader));

    if( typeof(bearerHeader) !== 'undefined' ){     
        //헤더에 토큰 정보가 있어 
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        req.token = bearerToken;
        next();
    }else{
        //정보가 없어 
        console.log('토큰 없음');
        res.json({
            status: 403, 
            message: '토큰이 없습니다.'
        });
    }
}

module.exports = router;