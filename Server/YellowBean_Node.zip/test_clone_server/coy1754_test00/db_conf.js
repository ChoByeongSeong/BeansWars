module.exports = {
    local:{
        host:'192.168.0.116',
        user:'root',
        password:'root',
        database:'test'
    },
    cafe24:{
        host:'10.0.0.1',
        user:'coy1754',
        password:'cZ4rxc4jLfTgYpV',
        database:'coy1754'
    },
    vultr: {

    }
}